const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

// Use express.json() to parse JSON request bodies
app.use(express.json());

app.use(cors()); // Enable cross-origin requests

// Serve static files from the 'frontend' folder
app.use(express.static(path.join(__dirname, '../assignment-manager-frontend')));

// In-memory array to hold assignments (for demo purposes)
let assignments = [];

// Route to get all assignments
app.get('/api/assignments', (req, res) => {
    res.json(assignments);
});

// Route to add a new assignment
app.post('/api/assignments', (req, res) => {
    const { title, description, deadline, weightage, estimatedTime } = req.body;

    // Validation: Ensure all fields are provided
    if (!title || !description || !deadline || !weightage || !estimatedTime) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    // Create a new assignment object
    const newAssignment = {
        title,
        description,
        deadline,
        weightage,
        estimatedTime
    };

    // Add the new assignment to the assignments array
    assignments.push(newAssignment);

    // Respond with the newly added assignment
    res.status(201).json(newAssignment);
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
