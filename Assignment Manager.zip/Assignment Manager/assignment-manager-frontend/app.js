// Function to add a new assignment
function addAssignment(event) {
    event.preventDefault();

    // Get values from the form
    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;
    const deadline = document.getElementById('deadline').value;
    const weightage = document.getElementById('weightage').value;
    const estimatedTime = document.getElementById('estimatedTime').value;

    // Create an assignment object
    const assignment = {
        title,
        description,
        deadline,
        weightage,
        estimatedTime
    };

    // Send a POST request to the backend to save the assignment
    fetch('http://localhost:3000/api/assignments', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(assignment)
    })
    .then(response => response.json())
    .then(data => {
        console.log('Assignment added:', data);
        fetchAssignments(); // Reload the list of assignments
    })
    .catch(error => console.error('Error adding assignment:', error));
}

// Function to fetch and display assignments
// Function to fetch and display assignments
function fetchAssignments() {
    fetch('http://localhost:3000/api/assignments')
        .then(response => response.json())
        .then(data => {
            // Find the container where the assignments will be displayed
            const assignmentList = document.getElementById('assignmentList');
            assignmentList.innerHTML = ''; // Clear the existing list

            // Loop through the assignments and display them
            data.forEach(assignment => {
                const assignmentItem = document.createElement('li');
                
                // Create title, description, and other details
                const title = document.createElement('div');
                title.classList.add('title');
                title.textContent = assignment.title;

                const description = document.createElement('div');
                description.classList.add('description');
                description.textContent = assignment.description;

                const details = document.createElement('div');
                details.classList.add('details');
                details.innerHTML = `Deadline: ${assignment.deadline} <br>
                                     Weightage: ${assignment.weightage} <br>
                                     Estimated Time: ${assignment.estimatedTime} hours`;

                // Append each part to the list item
                assignmentItem.appendChild(title);
                assignmentItem.appendChild(description);
                assignmentItem.appendChild(details);

                // Append the assignment item to the list
                assignmentList.appendChild(assignmentItem);
            });
        })
        .catch(error => console.error('Error fetching assignments:', error));
}


// Call fetchAssignments to load the assignments when the page loads
document.addEventListener('DOMContentLoaded', fetchAssignments);

// Add event listener to the form submission
document.getElementById('assignmentForm').addEventListener('submit', addAssignment);
